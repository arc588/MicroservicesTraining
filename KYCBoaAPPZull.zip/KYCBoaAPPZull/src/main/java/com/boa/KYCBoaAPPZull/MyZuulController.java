package com.boa.KYCBoaAPPZull;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MyZuulController {

	@Autowired
	private DiscoveryClient discoveryClient;
	
	@ResponseBody
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String home() {
		return "<a href='showAllServiceIds'>ShowAllServices</a>";
	}
	
	@ResponseBody
	@RequestMapping(value="/showAllServiceIds", method=RequestMethod.GET)
	public String showAllServiceIds() {
		List<String> serviceIds= this.discoveryClient.getServices();
		if(serviceIds==null || serviceIds.isEmpty()) {
			return "No service found";
		}
		String html="<h3>Service IDs</h3>";
		
		for(String serviceId:serviceIds) {
			html="<br><a href='showService?serviceId="+serviceId+" '>"+ serviceId+"</a>";
		}
		return html;
	}
	
	@ResponseBody
	@RequestMapping(value="/showService", method=RequestMethod.GET)
	public String showService(@RequestParam(defaultValue="") String serviceId) {
		List<ServiceInstance> instances=this.discoveryClient.getInstances(serviceId);
		
		if(instances==null || instances.isEmpty()) {
			return "No instance for service found"+serviceId;
		}
		String html="<h2>Instances for Service id ID: "+serviceId+"</h2>";
		
		for(ServiceInstance serviceInstance:instances) {
			html+="<h3>Instance: "+serviceInstance.getUri()+"</h3>";
			html+="<h3>Host: "+serviceInstance.getHost()+"</h3>";
			html+="<h3>Port: "+serviceInstance.getPort()+"</h3>";
			html+="<h3>subpath: "+serviceInstance.getMetadata()+"</h3>";
		}
		return html;
	}
}
