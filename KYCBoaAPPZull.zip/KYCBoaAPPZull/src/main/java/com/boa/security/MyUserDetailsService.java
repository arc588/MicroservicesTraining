package com.boa.security;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.boa.model.BoaUser;
public class MyUserDetailsService implements UserDetailsService{


	private List<BoaUser> boaUserList= new ArrayList();
	
	 public MyUserDetailsService() {
		 this.boaUserList.add(new BoaUser("abc", "123", "ADMIN"));
		 this.boaUserList.add(new BoaUser("pqr", "234", "USER"));
		 this.boaUserList.add(new BoaUser("xyz", "456", "ADMIN"));
	}
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Optional<BoaUser> response = boaUserList.stream()
                .filter(u -> u.getUsername().equals(username))
                .findAny();
		
		if(!response.isPresent()) {
			throw new UsernameNotFoundException("User not found with username"+username);
		}
		else {
			return toUserDetails(response.get());
		}
	}

	private UserDetails toUserDetails(BoaUser boaUser) {
		PasswordEncoder encoder =new BCryptPasswordEncoder();
        return User.withUsername(boaUser.getUsername())
                   .password(encoder.encode(boaUser.getPassword()))
                   .roles(boaUser.getRole()).build();
		
	}

}
