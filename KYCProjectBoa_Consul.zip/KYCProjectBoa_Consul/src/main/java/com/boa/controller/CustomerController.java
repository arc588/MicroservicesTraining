package com.boa.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.configuration.DBConfiguration;
import com.boa.models.Customer;
import com.boa.services.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private DBConfiguration dbConfig;
	
	@Autowired
	private CustomerService customerService;
	
	//add the customer
	@CrossOrigin("*")//allow access between diff domains ex: Google and OLA 
	@PostMapping("/addCustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer) {
		return this.customerService.addCustomer(customer);		
	}
	
	//get all customers
	@CrossOrigin("*")
	@GetMapping("/getAllCustomers")
	public @ResponseBody List<Customer> getAllCustomers(){
		return this.customerService.getAllCustomers();
	}
	
	//getOne customer by id
	@CrossOrigin("*")
	@GetMapping("/getCustomerbyId/{id}")
	public @ResponseBody Customer getCustomerbyId(@PathVariable int id) {
		return customerService.getCustomerbyId(id);
	}
	//delete customer by id
	@CrossOrigin("*")
	@DeleteMapping("/deletebyCustomerId/{id}")
	public void deleteCustomer(@PathVariable int id) {
		customerService.deleteCustomerbyId(id);
	}
	
	//update customerfirstname
	@CrossOrigin("*")
	@GetMapping("/updateCustomerFirstName/{id}/{firstName}")
	public void updateCustomerFirstName(@PathVariable int id, @PathVariable String firstName) {
		customerService.upfateCustomerFirstName(id, firstName);
	}
	
	@PutMapping("updateCustomer/{id}")
	public Customer updateCustomer(@PathVariable int id, @RequestBody Customer customer) {
		
		Customer cust=this.customerService.getCustomerbyId(id);
		cust.setCustomerID(id);
		cust.setFirstName(customer.getFirstName());
		cust.setLastName(customer.getLastName());
		cust.setDob(customer.getDob());
		cust.setAddress(customer.getFirstName());
		Customer updatedCustomer =this.customerService.addCustomer(cust);	
		return updatedCustomer;
	}

	//pick the db based on run time prop value like MONGO or MYSQL
	@GetMapping("/conditionalMapping")
	public List getAllTransactions() {
		System.out.println("which env prop"+message);//prints this mesaage value from env which u set in application.properties
		return dbConfig.mongodbTransactions().getAllTransactions();
	}
	
	
	@Value("${message}")
	String message;
	
}
