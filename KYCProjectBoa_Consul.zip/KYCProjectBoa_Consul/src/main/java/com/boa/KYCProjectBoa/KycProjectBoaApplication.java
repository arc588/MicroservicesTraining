package com.boa.KYCProjectBoa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.boa.configuration.DBConfiguration;
import com.boa.models.MongoTransaction;

@EnableDiscoveryClient
@SpringBootApplication
//@EnableAutoConfiguration(exclude=(DataSourceAutoConfiguration.class))
@ComponentScan(basePackages="com.boa.*")//enable the controller
@EnableJpaRepositories(basePackages="com.boa.*")//enable the repositories
@EntityScan(basePackages="com.boa.*")//scan the entities
@EnableMongoRepositories(basePackages="com.boa.*")

//public class KycProjectBoaApplication implements CommandLineRunner{

public class KycProjectBoaApplication {
	//private DBConfiguration dbConfig;
	
	public static void main(String[] args) {
		//System.setProperty("dbType", "MONGODB");
		//String[] appArgs= {"--debug"};		
		//SpringApplication.run(KycProjectBoaApplication.class, args);
		SpringApplication app= new SpringApplication(KycProjectBoaApplication.class);
		app.setLogStartupInfo(false);
		app.run();		
	}
/*
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		for(Object obj: dbConfig.mongodbTransactions().getAllTransactions()) {
			MongoTransaction mtransaction=(MongoTransaction)obj;
			System.out.println("Amount is---"+mtransaction.getAmount());
		}
		
	}*/

}

