package com.boa.services;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.models.Customer;
import com.boa.repositories.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository custRepo;
	
	//add customer	
	public Customer addCustomer(Customer customer) {
		return custRepo.save(customer);
	}
	
	//get customer by id
	public Customer getCustomerbyId(int id) {
		return custRepo.findById(id).orElse(null);
	}
	
	//select all customers
	public List<Customer> getAllCustomers(){
		return custRepo.findAll();
	}
	
	//delete the customer
	public void deleteCustomerbyId(int id) {
		 custRepo.deleteById(id);
	}
	
	//update customer firstname
	@Transactional(value=TxType.REQUIRED)
	public void upfateCustomerFirstName(int id,String firstName) {
		custRepo.updateCustomer(id, firstName);
		
	}

}
