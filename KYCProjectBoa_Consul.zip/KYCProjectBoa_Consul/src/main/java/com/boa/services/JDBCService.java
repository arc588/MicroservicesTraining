package com.boa.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.models.JDBCTransaction;
import com.boa.repositories.JDBCTransactionReposirtory;

@Service
public class JDBCService {

	@Autowired
	private JDBCTransactionReposirtory jdbcRepository;
	
	public JDBCTransaction addTransaction(JDBCTransaction jdbcTransaction) {
		return this.jdbcRepository.save(jdbcTransaction);
	}
	
	public List<JDBCTransaction> getAllTransactions(){
		return this.jdbcRepository.findAll();
	}
	
}
