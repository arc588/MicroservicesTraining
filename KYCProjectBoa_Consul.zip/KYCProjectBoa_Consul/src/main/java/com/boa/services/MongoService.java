package com.boa.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.models.MongoTransaction;
import com.boa.repositories.MongoTransactionRepository;

@Service
public class MongoService {
	
	@Autowired
	private MongoTransactionRepository mongoRepository;
	
	//add the transaction
	public MongoTransaction addTransaction(MongoTransaction mongoTransaction)
	{
		return mongoRepository.save(mongoTransaction);
	}
	
	//select all	
	public List<MongoTransaction> getAllTransactions(){
		return mongoRepository.findAll();
		
	}

}
