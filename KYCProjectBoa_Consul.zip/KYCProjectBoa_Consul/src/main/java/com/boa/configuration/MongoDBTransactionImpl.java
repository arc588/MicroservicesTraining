package com.boa.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.boa.services.MongoService;

public class MongoDBTransactionImpl implements TransactionData{

	@Autowired
	private MongoService mongoService;
	
	@Override
	public List getAllTransactions() {
		// TODO Auto-generated method stub
		return mongoService.getAllTransactions();
	}

}
