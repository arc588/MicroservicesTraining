package com.boa.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.boa.services.JDBCService;

public class JDBCTransactionImpl implements TransactionData{

	@Autowired
	private JDBCService jdbcService;
	
	@Override
	public List getAllTransactions() {
		return jdbcService.getAllTransactions();
	}

}
