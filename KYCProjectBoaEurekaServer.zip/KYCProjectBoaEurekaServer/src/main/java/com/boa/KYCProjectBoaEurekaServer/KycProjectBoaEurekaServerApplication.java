package com.boa.KYCProjectBoaEurekaServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class KycProjectBoaEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycProjectBoaEurekaServerApplication.class, args);
	}

}

