package com.boa.repository;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.boa.controller.RibbonFeignClientConfig;

//BOAKYCAPP refers to the line in prop file i.e (BOAKYCAPP.ribbon.listOfServers=http://localhost:8001,http://localhost:8002,http://localhost:8003)
//RIBBONLISTOFSERVERS refres to my own name it can be anything
@FeignClient(name="BOAKYCAPP",configuration=RibbonFeignClientConfig.class)
@RibbonClient(name="RIBBONLISTOFSERVERS")
public interface RibbonRepository {
	
	@GetMapping("/getAllCustomers")
	public ResponseEntity<String> retriveAssests(); 

}
