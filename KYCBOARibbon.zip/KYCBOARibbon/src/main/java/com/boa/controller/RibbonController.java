package com.boa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.repository.RibbonRepository;

@RestController
public class RibbonController {
	
	@Autowired
	private RibbonRepository ribbonRepository;
	
	@GetMapping("/getFeignAllCustomers")
	public String getFeignCustomerData() {
		ResponseEntity<String> response=this.ribbonRepository.retriveAssests();
		return response.getBody();
	}

}
