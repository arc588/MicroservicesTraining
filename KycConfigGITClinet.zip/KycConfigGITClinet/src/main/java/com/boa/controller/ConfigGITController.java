package com.boa.controller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class ConfigGITController {
	
	@Value("${user.firstName}")
	private String firstName;
	
	@Value("${user.lastName}")
	private String lastName;
	
	@Value("${user.dob}")
	private String dob;
	
	@Value("${user.country}")
	private String country;
	
	@ResponseBody
	@RequestMapping("/showConfigServer")
	public String showConfigServer() {
		String configInfo=  "<br>user.firstName="+firstName+
							"<br>user.lastName="+lastName+
							"<br>user.dob="+dob+
							"<br>user.country="+country;
		return configInfo;
	}
}
