package com.boa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CBDelegate {

	@Autowired
	private RestTemplate restTemplate;
	
	@Bean
	public RestTemplate  getRestTemplate() {
		return new RestTemplate();
	}
	
	@HystrixCommand(fallbackMethod="handleRequestFallback")
	public String handleRequest(int id) {
		//instance level 
		String response=restTemplate.exchange("http://localhost:8001/getCustomerbyId/{id}",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {},
				id).getBody();
		return response;
	}
	
	private String handleRequestFallback(int id) {
		
		//instance level 
		String response=restTemplate.exchange("http://localhost:8002/getCustomerbyId/{id}",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {},
				id).getBody();
		return response;

	}
}
