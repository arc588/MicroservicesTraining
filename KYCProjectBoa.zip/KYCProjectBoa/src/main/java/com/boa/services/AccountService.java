package com.boa.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.models.Account;
import com.boa.models.Customer;
import com.boa.repositories.AccountRepository;
import com.boa.repositories.CustomerRepository;

@Service
public class AccountService {
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private CustomerService customerService;	
	
	@Autowired
	private CustomerRepository customerrepo;
	
	//add account	
	public Account addAccount(Account account, int customerid) {
		Customer customerObj= customerService.getCustomerbyId(customerid);
		System.out.println("");
		account.setCustomer(customerObj);
		return accountRepository.save(account);
	}
	
	//get account by id
	public Account getAccountById(int accountId) {
		return accountRepository.findById(accountId).orElse(null);
	}
	
	//select all accounts
	public List<Account> getAllAccounts(){
		return accountRepository.findAll();
	}
	
	
}
