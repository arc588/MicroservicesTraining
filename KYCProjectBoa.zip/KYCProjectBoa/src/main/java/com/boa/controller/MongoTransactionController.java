package com.boa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.boa.models.MongoTransaction;
import com.boa.services.MongoService;

@Controller
public class MongoTransactionController {
	
	@Autowired
	private MongoService mongoService;
	
	@RequestMapping("/transaction")
	public String loadHome(Model model) {
		model.addAttribute("transactionList",mongoService.getAllTransactions());
		return "home";
	}
	
	@RequestMapping(value="/addTransaction",method=RequestMethod.POST)
	public String createTransaction(@ModelAttribute MongoTransaction mongoObj) {
		this.mongoService.addTransaction(mongoObj);
		return "redirect:transaction";
	}

}
