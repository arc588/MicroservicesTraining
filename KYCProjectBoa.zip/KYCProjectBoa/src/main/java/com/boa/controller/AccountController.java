package com.boa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.models.Account;
import com.boa.models.Customer;
import com.boa.services.AccountService;
import com.boa.services.CustomerService;

@RestController
public class AccountController {

	@Autowired
	private AccountService accountService;
	
	//add the customer
	@CrossOrigin("*") 
	@PostMapping("/addAccount/{customerId}")
	public @ResponseBody Account addAccount(@RequestBody Account account, @PathVariable int customerId) {
		return this.accountService.addAccount(account,customerId);		
	}
	
	//get all customers
	@CrossOrigin("*")
	@GetMapping("/getAllAccounts")
	public @ResponseBody List<Account> getAllAccounts(){
		return this.accountService.getAllAccounts();
	}
	
	//getOne customer by id
	@CrossOrigin("*")
	@GetMapping("/getAccountbyId/{id}")
	public @ResponseBody Account getCustomerbyId(@PathVariable int id) {
		return accountService.getAccountById(id);
	}
	
	/*//delete customer by id
	@CrossOrigin("*")
	@DeleteMapping("/deletebyCustomerId/{id}")
	public void deleteCustomer(@PathVariable int id) {
		customerService.deleteCustomerbyId(id);
	}
	
	//update customerfirstname
	@CrossOrigin("*")
	@GetMapping("/updateCustomerFirstName/{id}/{firstName}")
	public void updateCustomerFirstName(@PathVariable int id, @PathVariable String firstName) {
		customerService.upfateCustomerFirstName(id, firstName);
	}
*/

}
