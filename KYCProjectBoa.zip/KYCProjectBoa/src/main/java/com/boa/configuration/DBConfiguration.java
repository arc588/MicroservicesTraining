package com.boa.configuration;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DBConfiguration {

	//the below are for accessing values from prod prop file 
	@Value("${DATABASE_URL}")
	String dbUrl;
	@Value("${DATABASE_USERNAME}")
	String dbUsername;	
	@Value("${DATABASE_PASSWORD}")
	String dbPassword;
	
	@Bean
	@ConditionalOnClass(DataSource.class)
	public DataSource getMySQLDataSource() {
		DataSourceBuilder dataSourceBuilder=DataSourceBuilder.create();
		
		// the below are for default hardcoded db setup
		/*dataSourceBuilder.url("jdbc:mysql://${DATABASE_HOST}/${DATABASE_NAME}?useSSL=true");
		dataSourceBuilder.username("root");
		dataSourceBuilder.password("root");
		*/
		
		//the below are for reading db prop from prop file
		dataSourceBuilder.url(dbUrl);
		dataSourceBuilder.username(dbUsername);
		dataSourceBuilder.password(dbPassword);
		return dataSourceBuilder.build();
	}
	
	@Bean
	@Conditional(JDBCDataTypeCondition.class)
	public TransactionData jdbcTransactions() {
		System.out.println("inside JDBC");
		return new JDBCTransactionImpl();
	}
	
	@Bean
	@Conditional(MongoDataTypeCondition.class)
	public TransactionData mongodbTransactions() {
		System.out.println("inside mongo");
		return new MongoDBTransactionImpl();
	}

}
