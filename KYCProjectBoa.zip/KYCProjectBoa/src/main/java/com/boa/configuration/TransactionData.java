package com.boa.configuration;

import java.util.List;

public interface TransactionData {
	
	List getAllTransactions();

}
