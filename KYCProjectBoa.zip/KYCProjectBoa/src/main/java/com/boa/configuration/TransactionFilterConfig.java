package com.boa.configuration;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.boa.filter.TransactionFilter;
import com.boa.filter.TransactionFilterTwo;

@Configuration
public class TransactionFilterConfig {
	
	@Bean
	public FilterRegistrationBean<TransactionFilter> registerFilterOne(){
		FilterRegistrationBean<TransactionFilter> regFilter=new FilterRegistrationBean<TransactionFilter>();
		TransactionFilter tf= new TransactionFilter();
		regFilter.setFilter(tf);
		regFilter.setOrder(1);
		regFilter.addUrlPatterns("/transaction/*");
		return regFilter;
	}
	
	@Bean
	public FilterRegistrationBean<TransactionFilterTwo> registerFilterTwo(){
		FilterRegistrationBean<TransactionFilterTwo> regFilter=new FilterRegistrationBean<TransactionFilterTwo>();
		TransactionFilterTwo tf= new TransactionFilterTwo();
		regFilter.setFilter(tf);
		regFilter.setOrder(2);//to check how the filters working..
		regFilter.addUrlPatterns("/transaction/*");
		return regFilter;
	}

}
