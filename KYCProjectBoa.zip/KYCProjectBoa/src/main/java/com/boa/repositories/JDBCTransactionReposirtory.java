package com.boa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.models.JDBCTransaction;

public interface JDBCTransactionReposirtory extends JpaRepository<JDBCTransaction, Integer> {

}
