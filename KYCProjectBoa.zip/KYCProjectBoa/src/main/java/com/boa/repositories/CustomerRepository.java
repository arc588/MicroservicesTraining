package com.boa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boa.models.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	
	@Modifying(clearAutomatically=true)
	@Query("update Customer set firstName=:firstName where customerId=:id")
	void updateCustomer(@Param("id")int id,@Param("firstName")String firstName ); 

}
